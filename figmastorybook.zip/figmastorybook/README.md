# figmastorybook
# Setting up repo
1. npm init
2. npm install react react-dom
3. npx -p @storybook/cli sb init --type react - https://storybook.js.org/docs/guides/guide-react/
4. npm install --save-dev storybook-addon-design

# To run storybook
1. Add the figma url in stories/1-Button.stories.js file in url parameter.
2. npm run storybook

